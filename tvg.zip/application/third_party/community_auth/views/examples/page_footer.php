</body>
</html>

<?php

/* End of file page_footer.php */
/* Location: /community_auth/views/examples/page_footer.php */